<?php

phpinfo();

function getIp() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

$ip = getIp();
$date = date ("d/m/Y:H:i:s");
$alert = "LANDING";
#$user_agent = isset($_SERVER['HTTP_USER_AGENT'])? $_SERVER['HTTP_USER_AGENT']:'Not Set' ;
$message = "$date,$ip,$alert\n"; 
$log = "../log.txt";
$file = fopen($log, "a+"); 
if ($file) { 
    fwrite($file, "$message"); 
    fclose ($file); 
}

?>